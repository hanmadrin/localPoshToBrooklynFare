import {allProducts} from './currentProducts.js';
const productWithCategoriesOnly = ()=>{
    
    
}
// productWithCategoriesOnly();



const uniqueCountWithCategories = ()=>{
    const result = {};
    let count = 0;
    for(let i=0;i<allProducts.length;i++){
        const product = allProducts[i];
        const productId = product.productId;
        const categories = product.family.categories.map((cat)=>cat.names['2']);
        result[productId] = {
            count: result[productId]?.count==null?1:result[productId].count+1,
            categories: result[productId]?.categories==null?categories:[...result[productId].categories,...categories]
        }
        count++;
        result[productId].categories = [...new Set(result[productId].categories)];
    }
    console.log(result,Object.keys(result),count)
};
uniqueCountWithCategories();